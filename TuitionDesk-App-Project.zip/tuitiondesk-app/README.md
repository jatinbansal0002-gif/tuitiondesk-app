# TuitionDesk — mobile-first web app demo

This project packages the supplied TuitionDesk React screen as a runnable Vite app.

## Run it
1. Install Node.js (18+ recommended).
2. Open this folder in a terminal.
3. Run `npm install`
4. Run `npm run dev`
5. Open the local URL shown by Vite.

## Demo sign-ins
- Parent: `9876543210` then demo OTP `4321`
- Other sample parents: `9812345678`, `9988776655`, `9711223344`, `9655443322`
- Owner: password `admin`

## Important limitations — not production-ready
- The five students and referrals are sample data.
- Sign-in is a front-end demo. OTP `4321` is hard-coded; there is no real SMS/WhatsApp OTP or secure authentication.
- Data lives only in browser memory and resets on refresh. There is no database or multi-device sync.
- WhatsApp actions are demo confirmations, not automatic message delivery.
- UPI ID/QR shown in the sample is a placeholder. The “mark fee as paid” demo control does not process or verify a payment.
- Do not enter real parent/student personal information until secure authentication, database rules, backups, and privacy controls are implemented.

## Next production steps
Connect a secure backend (for example Firebase/Supabase), implement real owner and parent accounts with role-based access, persist attendance/fees/referrals, configure the real UPI QR, and add manual payment-proof review. For WhatsApp automation, use the official WhatsApp Business Platform through an approved provider; a normal web page cannot silently send bulk WhatsApp messages.
