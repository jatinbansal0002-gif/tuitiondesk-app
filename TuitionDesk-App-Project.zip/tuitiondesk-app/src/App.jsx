import React, { useState } from 'react';
import { 
  IndianRupee, 
  Users, 
  UserCheck, 
  Award, 
  Smartphone, 
  BarChart3, 
  Send, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  QrCode, 
  Share2, 
  BookOpen, 
  MessageSquare,
  Sparkles,
  TrendingUp,
  Check,
  ChevronRight,
  ShieldCheck,
  Zap,
  Gift,
  Lock,
  Phone,
  LogOut,
  User,
  Crown,
  Search,
  ArrowRight
} from 'lucide-react';

// --- INITIAL SAMPLE DATA ---
const INITIAL_STUDENTS = [
  {
    id: 's1',
    name: 'Aarav Sharma',
    class: 'Class 10',
    batch: 'Class 10 - Maths/Sci',
    parentName: 'Rajesh Sharma',
    parentPhone: '9876543210',
    feeStatus: 'Overdue',
    feeAmount: 2500,
    daysLate: 12,
    todayAttendance: 'P',
    attendancePercent: 94,
    rank: 1,
    weeklyTestMarks: '48 / 50',
    testHistory: [
      { test: 'T1', mark: 40 },
      { test: 'T2', mark: 42 },
      { test: 'T3', mark: 45 },
      { test: 'T4', mark: 44 },
      { test: 'T5', mark: 47 },
      { test: 'T6', mark: 48 },
    ],
    homework: 'NCERT Ch 4 Exercise 4.3 (Q1 to Q8)',
    referredBy: 'Self'
  },
  {
    id: 's2',
    name: 'Riya Patel',
    class: 'Class 10',
    batch: 'Class 10 - Maths/Sci',
    parentName: 'Suresh Patel',
    parentPhone: '9812345678',
    feeStatus: 'Paid',
    feeAmount: 2500,
    daysLate: 0,
    todayAttendance: 'P',
    attendancePercent: 98,
    rank: 2,
    weeklyTestMarks: '45 / 50',
    testHistory: [
      { test: 'T1', mark: 38 },
      { test: 'T2', mark: 40 },
      { test: 'T3', mark: 42 },
      { test: 'T4', mark: 43 },
      { test: 'T5', mark: 44 },
      { test: 'T6', mark: 45 },
    ],
    homework: 'NCERT Ch 4 Exercise 4.3 (Q1 to Q8)',
    referredBy: 'Priya Verma'
  },
  {
    id: 's3',
    name: 'Rohan Gupta',
    class: 'Class 9',
    batch: 'Class 9 - Science',
    parentName: 'Anil Gupta',
    parentPhone: '9988776655',
    feeStatus: 'Overdue',
    feeAmount: 2200,
    daysLate: 8,
    todayAttendance: 'A',
    attendancePercent: 82,
    rank: 5,
    weeklyTestMarks: '32 / 50',
    testHistory: [
      { test: 'T1', mark: 28 },
      { test: 'T2', mark: 30 },
      { test: 'T3', mark: 35 },
      { test: 'T4', mark: 31 },
      { test: 'T5', mark: 34 },
      { test: 'T6', mark: 32 },
    ],
    homework: 'Prepare diagram of Plant & Animal Cells',
    referredBy: 'Self'
  },
  {
    id: 's4',
    name: 'Ananya Singh',
    class: 'Class 10',
    batch: 'Class 10 - Maths/Sci',
    parentName: 'Vikram Singh',
    parentPhone: '9711223344',
    feeStatus: 'Pending',
    feeAmount: 2500,
    daysLate: 3,
    todayAttendance: 'P',
    attendancePercent: 89,
    rank: 3,
    weeklyTestMarks: '41 / 50',
    testHistory: [
      { test: 'T1', mark: 35 },
      { test: 'T2', mark: 37 },
      { test: 'T3', mark: 39 },
      { test: 'T4', mark: 40 },
      { test: 'T5', mark: 38 },
      { test: 'T6', mark: 41 },
    ],
    homework: 'NCERT Ch 4 Exercise 4.3 (Q1 to Q8)',
    referredBy: 'Aarav Sharma'
  },
  {
    id: 's5',
    name: 'Kabir Mehta',
    class: 'Class 9',
    batch: 'Class 9 - Science',
    parentName: 'Sunita Mehta',
    parentPhone: '9655443322',
    feeStatus: 'Overdue',
    feeAmount: 2200,
    daysLate: 15,
    todayAttendance: 'A',
    attendancePercent: 76,
    rank: 7,
    weeklyTestMarks: '26 / 50',
    testHistory: [
      { test: 'T1', mark: 20 },
      { test: 'T2', mark: 22 },
      { test: 'T3', mark: 25 },
      { test: 'T4', mark: 28 },
      { test: 'T5', mark: 24 },
      { test: 'T6', mark: 26 },
    ],
    homework: 'Prepare diagram of Plant & Animal Cells',
    referredBy: 'Self'
  }
];

const INITIAL_REFERRALS = [
  { id: 'r1', name: 'Sneha Roy', class: 'Class 10', referrer: 'Aarav Sharma', date: 'Yesterday', status: 'Contacted' },
  { id: 'r2', name: 'Dev Verma', class: 'Class 9', referrer: 'Riya Patel', date: '3 days ago', status: 'Joined' },
  { id: 'r3', name: 'Isha Kapoor', class: 'Class 8', referrer: 'Ananya Singh', date: '5 days ago', status: 'Pending' }
];

export default function App() {
  // Auth state: null | { role: 'owner' } | { role: 'parent', studentId: string }
  const [currentUser, setCurrentUser] = useState(null);
  const [loginRoleTab, setLoginRoleTab] = useState('parent'); // 'parent' or 'owner'
  
  // Login Inputs
  const [phoneInput, setPhoneInput] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpInput, setOtpInput] = useState('');
  const [ownerPass, setOwnerPass] = useState('');
  const [authError, setAuthError] = useState('');

  // Main Tabs & App State
  const [activeTab, setActiveTab] = useState('fees');
  const [students, setStudents] = useState(INITIAL_STUDENTS);
  const [referrals, setReferrals] = useState(INITIAL_REFERRALS);
  
  // Modals & Pitch
  const [toastMsg, setToastMsg] = useState('');
  const [whatsappModal, setWhatsappModal] = useState({ open: false, title: '', message: '', recipient: '' });
  const [upiModal, setUpiModal] = useState(false);
  const [showPitch, setShowPitch] = useState(false);
  
  // Referral Form State in Parent Portal
  const [referralName, setReferralName] = useState('');
  const [referralClass, setReferralClass] = useState('Class 10');

  const triggerToast = (msg) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(''), 3200);
  };

  // --- LOGIN LOGIC ---
  const handleSendOtp = (e) => {
    e.preventDefault();
    setAuthError('');
    const cleanPhone = phoneInput.trim().replace(/\D/g, '');
    const matchedStudent = students.find(s => s.parentPhone === cleanPhone || s.parentPhone.endsWith(cleanPhone));
    
    if (!cleanPhone || cleanPhone.length < 10) {
      setAuthError('Please enter a valid 10-digit mobile number');
      return;
    }

    if (!matchedStudent) {
      setAuthError('Number not registered! Demo numbers: 9876543210, 9812345678, 9988776655');
      return;
    }

    setOtpSent(true);
    triggerToast(`Demo OTP is 4321 (no SMS/WhatsApp was sent)`);
  };

  const handleParentLogin = (e) => {
    e.preventDefault();
    setAuthError('');
    const cleanPhone = phoneInput.trim().replace(/\D/g, '');
    const matchedStudent = students.find(s => s.parentPhone === cleanPhone || s.parentPhone.endsWith(cleanPhone));

    if (otpInput !== '4321' && otpInput !== '1234') {
      setAuthError('Invalid OTP! Enter demo OTP: 4321');
      return;
    }

    if (matchedStudent) {
      setCurrentUser({ role: 'parent', studentId: matchedStudent.id });
      setActiveTab('parentView');
      setOtpSent(false);
      setPhoneInput('');
      setOtpInput('');
      triggerToast(`Welcome Parent of ${matchedStudent.name}!`);
    }
  };

  const handleOwnerLogin = (e) => {
    e.preventDefault();
    setAuthError('');
    if (ownerPass === 'admin' || ownerPass === '1234' || ownerPass === 'owner') {
      setCurrentUser({ role: 'owner' });
      setActiveTab('fees');
      setOwnerPass('');
      triggerToast('Welcome Owner Dashboard!');
    } else {
      setAuthError('Incorrect Password! (Default demo password: admin)');
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setOtpSent(false);
    setPhoneInput('');
    setOtpInput('');
    setOwnerPass('');
    setAuthError('');
    triggerToast('Logged out successfully');
  };

  // --- ACTIONS ---
  const handleToggleAttendance = (id) => {
    if (currentUser?.role !== 'owner') return;
    setStudents(prev => prev.map(s => s.id === id ? { ...s, todayAttendance: s.todayAttendance === 'P' ? 'A' : 'P' } : s));
  };

  const handleSaveAttendance = () => {
    if (currentUser?.role !== 'owner') return;
    const absentStudents = students.filter(s => s.todayAttendance === 'A');
    if (absentStudents.length > 0) {
      triggerToast(`Saved! WhatsApp absent alerts sent to ${absentStudents.length} parents.`);
    } else {
      triggerToast(`Saved! All students marked Present today.`);
    }
  };

  const handleSendAllFeeReminders = () => {
    if (currentUser?.role !== 'owner') return;
    const overdueList = students.filter(s => s.feeStatus !== 'Paid');
    if (overdueList.length === 0) {
      triggerToast('All fees are cleared! No reminders needed.');
      return;
    }
    setWhatsappModal({
      open: true,
      title: `Bulk WhatsApp Fee Reminders (${overdueList.length} Parents)`,
      recipient: `${overdueList.length} Overdue Parents`,
      message: `Dear Parent, This is a gentle reminder that tuition fees for your child are pending. Please pay via UPI or cash. Thank you! - TuitionDesk`
    });
  };

  const handleSingleFeeReminder = (student) => {
    if (currentUser?.role !== 'owner') return;
    setWhatsappModal({
      open: true,
      title: `WhatsApp Fee Reminder`,
      recipient: `${student.parentName} (+91 ${student.parentPhone})`,
      message: `Dear Parent (${student.parentName}), tuition fees of ₹${student.feeAmount} for ${student.name} (${student.class}) are overdue by ${student.daysLate} days. Kindly pay via UPI in the Parent App. Thank you!`
    });
  };

  const handleShareTestReport = (student) => {
    setWhatsappModal({
      open: true,
      title: `Weekly Test Progress Share`,
      recipient: `${student.parentName} (+91 ${student.parentPhone})`,
      message: `📊 Weekly Test Results for ${student.name} (${student.class}):\nMarks: ${student.weeklyTestMarks}\nBatch Rank: #${student.rank}\nOverall Attendance: ${student.attendancePercent}%\n\nLog into Parent App for full 6-test analysis graph!`
    });
  };

  const markFeePaid = (studentId) => {
    setStudents(prev => prev.map(s => s.id === studentId ? { ...s, feeStatus: 'Paid', daysLate: 0 } : s));
    setUpiModal(false);
    triggerToast('Demo update only: fee status changed locally. No payment was processed.');
  };

  const handleAddReferral = (e, referrerName) => {
    e.preventDefault();
    if (!referralName.trim()) return;
    const newRef = {
      id: 'r' + (referrals.length + 1),
      name: referralName.trim(),
      class: referralClass,
      referrer: referrerName,
      date: 'Just now',
      status: 'Pending'
    };
    setReferrals([newRef, ...referrals]);
    setReferralName('');
    triggerToast('Referral submitted! Owner notified.');
  };

  // Calculations
  const activeParentStudent = currentUser?.role === 'parent' 
    ? students.find(s => s.id === currentUser.studentId) || students[0]
    : students[0];

  // FILTERED STUDENT LIST: Parents only see their own child's information, Owner sees everyone
  const displayedStudents = currentUser?.role === 'parent'
    ? students.filter(s => s.id === currentUser.studentId)
    : students;

  const totalCollected = students.filter(s => s.feeStatus === 'Paid').reduce((acc, curr) => acc + curr.feeAmount, 0);
  const totalPending = students.filter(s => s.feeStatus !== 'Paid').reduce((acc, curr) => acc + curr.feeAmount, 0);

  return (
    <div className="min-h-screen bg-[#F4F6F9] text-[#0F172A] flex justify-center font-sans">
      
      {/* MOBILE DEVICE CONTAINER */}
      <div className="w-full max-w-md bg-[#F4F6F9] min-h-screen flex flex-col shadow-2xl relative border-x border-slate-300 overflow-hidden">
        
        {/* --- HEADER: NAVY BLUE (#0B132B) --- */}
        <header className="bg-[#0B132B] text-white p-4 sticky top-0 z-30 flex items-center justify-between shadow-lg">
          <div className="flex items-center space-x-2.5">
            <div className="bg-[#D4AF37] p-2 rounded-xl text-[#0B132B] shadow-md">
              <BookOpen className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="font-extrabold text-base tracking-tight text-white">
                  TuitionDesk
                </h1>
                <span className="text-[9px] font-black bg-[#D4AF37] text-[#0B132B] px-1.5 py-0.5 rounded uppercase tracking-wider">
                  PRO
                </span>
              </div>
              <p className="text-[10px] text-slate-300 font-medium">Smart Tuition Companion</p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setShowPitch(!showPitch)}
              className="flex items-center space-x-1 bg-[#D4AF37]/20 border border-[#D4AF37] text-[#D4AF37] px-2.5 py-1 rounded-full text-[11px] font-bold hover:bg-[#D4AF37]/30 transition-all"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Pitch</span>
            </button>

            {currentUser && (
              <button
                onClick={handleLogout}
                title="Logout"
                className="p-1.5 bg-slate-800 hover:bg-slate-700 text-rose-300 rounded-lg border border-slate-700 transition-all"
              >
                <LogOut className="w-4 h-4" />
              </button>
            )}
          </div>
        </header>

        {/* --- OWNER SALES PITCH BANNER --- */}
        {showPitch && (
          <div className="bg-[#0B132B] text-white border-b-2 border-[#D4AF37] p-4 space-y-3 animate-fadeIn relative z-20">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#D4AF37] uppercase tracking-wide flex items-center gap-1">
                <Crown className="w-4 h-4 text-[#D4AF37]" /> Owner pitch & Demo Strategy
              </span>
              <button onClick={() => setShowPitch(false)} className="text-xs text-slate-400 hover:text-white">✕</button>
            </div>
            <div className="space-y-2 text-xs text-slate-200 leading-relaxed">
              <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-700">
                <p className="font-bold text-[#D4AF37]">1. Phone Demo Pitch:</p>
                <p className="text-slate-300">Owner ko exact demo mobile pe dikhao: "Dekho 1 tap me saare pending fees parents ko WhatsApp alert chale jaate hain."</p>
              </div>
              <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-700">
                <p className="font-bold text-[#D4AF37]">2. 1 Month Free Pilot:</p>
                <p className="text-slate-300">"Pehla 1 mahina 100% FREE pilot chalao. Direct results dekho, pasand aaye tabhi aage badhna."</p>
              </div>
              <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-700">
                <p className="font-bold text-[#D4AF37]">3. Low-cost Monetization:</p>
                <p className="text-slate-300">One-time setup build charge (e.g. ₹1,499) + small monthly maintenance (₹299/mo) for WhatsApp triggers & updates.</p>
              </div>
            </div>
          </div>
        )}

        {/* --- SYSTEM TOAST ALERT --- */}
        {toastMsg && (
          <div className="mx-4 mt-3 bg-[#16A34A] text-white px-3.5 py-2.5 rounded-2xl text-xs font-semibold shadow-xl flex items-center space-x-2 border border-emerald-300 relative z-20">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-white" />
            <span>{toastMsg}</span>
          </div>
        )}

        {/* ========================================================================= */}
        {/* LOGIN SCREEN (IF NO USER LOGGED IN) */}
        {/* ========================================================================= */}
        {!currentUser ? (
          <div className="flex-1 p-5 flex flex-col justify-center space-y-6 relative z-10">
            
            <div className="text-center space-y-2">
              <div className="w-16 h-16 bg-[#0B132B] rounded-3xl mx-auto flex items-center justify-center shadow-lg border-2 border-[#D4AF37] p-0.5">
                <BookOpen className="w-8 h-8 text-[#D4AF37]" />
              </div>
              <h2 className="text-xl font-extrabold text-[#0F172A] tracking-tight pt-1">Welcome to TuitionDesk</h2>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">Select your portal to login to your dedicated app dashboard</p>
            </div>

            {/* ROLE TAB SWITCHER */}
            <div className="bg-slate-200 p-1 rounded-2xl border border-slate-300 flex text-xs font-bold">
              <button
                onClick={() => { setLoginRoleTab('parent'); setAuthError(''); }}
                className={`flex-1 py-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                  loginRoleTab === 'parent'
                    ? 'bg-[#0B132B] text-[#D4AF37] shadow-md'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Smartphone className="w-4 h-4" />
                <span>Parent Portal</span>
              </button>

              <button
                onClick={() => { setLoginRoleTab('owner'); setAuthError(''); }}
                className={`flex-1 py-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                  loginRoleTab === 'owner'
                    ? 'bg-[#0B132B] text-[#D4AF37] shadow-md'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Crown className="w-4 h-4" />
                <span>Owner Login</span>
              </button>
            </div>

            {/* ERROR DISPLAY */}
            {authError && (
              <div className="bg-red-50 border border-[#DC2626] p-3 rounded-2xl text-[#DC2626] text-xs flex items-start space-x-2 font-medium">
                <AlertCircle className="w-4 h-4 shrink-0 text-[#DC2626] mt-0.5" />
                <span>{authError}</span>
              </div>
            )}

            {/* PARENT LOGIN FORM */}
            {loginRoleTab === 'parent' && (
              <div className="bg-white border border-slate-300 rounded-3xl p-5 space-y-4 shadow-md">
                <div className="space-y-1">
                  <h3 className="font-bold text-sm text-[#0F172A] flex items-center gap-1.5">
                    <Phone className="w-4 h-4 text-[#0B132B]" />
                    <span>Parent Phone Login</span>
                  </h3>
                  <p className="text-[11px] text-slate-500">Enter registered WhatsApp mobile number</p>
                </div>

                {!otpSent ? (
                  <form onSubmit={handleSendOtp} className="space-y-3">
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Mobile Number</label>
                      <div className="relative">
                        <span className="absolute left-3 top-3 text-xs font-bold text-slate-500">+91</span>
                        <input
                          type="tel"
                          value={phoneInput}
                          onChange={(e) => setPhoneInput(e.target.value)}
                          placeholder="e.g. 9876543210"
                          className="w-full bg-[#F4F6F9] border border-slate-300 focus:border-[#0B132B] rounded-xl py-2.5 pl-12 pr-3 text-xs text-[#0F172A] outline-none font-mono"
                        />
                      </div>
                    </div>

                    {/* MAIN BUTTON: CHAMPAGNE GOLD (#D4AF37) */}
                    <button
                      type="submit"
                      className="w-full bg-[#D4AF37] hover:bg-[#C59B27] text-[#0B132B] font-extrabold py-3 rounded-xl text-xs shadow-md flex items-center justify-center space-x-1.5 transition-all"
                    >
                      <span>Send OTP via WhatsApp</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>

                    <div className="pt-2 text-[10px] text-slate-500 border-t border-slate-200">
                      <p className="font-semibold text-slate-600">Demo Parent Numbers to Test:</p>
                      <p className="font-mono text-[#0B132B] font-bold mt-0.5">9876543210 (Aarav) | 9812345678 (Riya)</p>
                    </div>
                  </form>
                ) : (
                  <form onSubmit={handleParentLogin} className="space-y-3">
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Enter WhatsApp OTP</label>
                      <input
                        type="text"
                        value={otpInput}
                        onChange={(e) => setOtpInput(e.target.value)}
                        placeholder="Enter demo OTP: 4321"
                        className="w-full bg-[#F4F6F9] border border-slate-300 focus:border-[#0B132B] rounded-xl py-2.5 px-3 text-xs text-[#0F172A] text-center font-mono tracking-widest outline-none"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-[#16A34A] hover:bg-emerald-700 text-white font-extrabold py-3 rounded-xl text-xs shadow-md flex items-center justify-center space-x-1.5 transition-all"
                    >
                      <ShieldCheck className="w-4 h-4" />
                      <span>Verify OTP & Access Portal</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setOtpSent(false)}
                      className="w-full text-[11px] text-slate-500 hover:text-slate-800 pt-1 text-center block"
                    >
                      ← Change Mobile Number
                    </button>
                  </form>
                )}
              </div>
            )}

            {/* OWNER LOGIN FORM */}
            {loginRoleTab === 'owner' && (
              <form onSubmit={handleOwnerLogin} className="bg-white border border-slate-300 rounded-3xl p-5 space-y-4 shadow-md">
                <div className="space-y-1">
                  <h3 className="font-bold text-sm text-[#0F172A] flex items-center gap-1.5">
                    <Lock className="w-4 h-4 text-[#0B132B]" />
                    <span>Tuition Admin Login</span>
                  </h3>
                  <p className="text-[11px] text-slate-500">Manage fees, attendance, reports & settings</p>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Admin Password</label>
                  <input
                    type="password"
                    value={ownerPass}
                    onChange={(e) => setOwnerPass(e.target.value)}
                    placeholder="Enter demo pass: admin"
                    className="w-full bg-[#F4F6F9] border border-slate-300 focus:border-[#0B132B] rounded-xl py-2.5 px-3 text-xs text-[#0F172A] font-mono outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#D4AF37] hover:bg-[#C59B27] text-[#0B132B] font-extrabold py-3 rounded-xl text-xs shadow-md flex items-center justify-center space-x-1.5 transition-all"
                >
                  <Crown className="w-4 h-4" />
                  <span>Login to Owner Dashboard</span>
                </button>

                <div className="pt-2 text-[10px] text-slate-500 border-t border-slate-200">
                  <p className="font-semibold text-slate-600">Demo Passcode:</p>
                  <p className="font-mono text-[#0B132B] font-bold mt-0.5">admin</p>
                </div>
              </form>
            )}

          </div>
        ) : (

          /* ========================================================================= */
          /* LOGGED IN APP MAIN NAVIGATION & CONTENT */
          /* ========================================================================= */
          <>
            {/* CURRENT USER STATUS BAR */}
            <div className="bg-[#0B132B]/90 text-white px-4 py-2 flex items-center justify-between text-xs">
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 rounded-full bg-[#16A34A] animate-pulse" />
                <span className="text-slate-200 text-[11px] font-medium">
                  LoggedIn as: <strong className="text-[#D4AF37] font-bold">{currentUser.role === 'owner' ? 'Tuition Owner' : `Parent (${activeParentStudent.name})`}</strong>
                </span>
              </div>

              {currentUser.role === 'parent' && (
                <span className="text-[10px] font-bold bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/40 px-2 py-0.5 rounded-full">
                  Read-Only Mode
                </span>
              )}
            </div>

            {/* TAB CONTENT AREA */}
            <main className="flex-1 p-4 pb-24 overflow-y-auto space-y-4 relative z-10">

              {/* PARENT MODE INFORMATIONAL BANNER */}
              {currentUser.role === 'parent' && (
                <div className="bg-[#0B132B]/5 border border-[#D4AF37]/40 p-2.5 rounded-xl flex items-center justify-between text-xs text-[#0B132B]">
                  <div className="flex items-center space-x-2">
                    <User className="w-4 h-4 text-[#D4AF37]" />
                    <span>Viewing reports for: <strong>{activeParentStudent.name}</strong> ({activeParentStudent.class})</span>
                  </div>
                </div>
              )}

              {/* ========================================= */}
              {/* TAB 1: FEES PENDING */}
              {/* ========================================= */}
              {activeTab === 'fees' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-base font-bold text-[#0F172A]">
                        {currentUser.role === 'parent' ? 'Child Fee Status' : 'Pending Fees'}
                      </h2>
                      <p className="text-xs text-slate-500">
                        {currentUser.role === 'parent' ? 'Check your payment due dates & history' : 'Track overdue days & auto-remind parents'}
                      </p>
                    </div>
                    {currentUser.role === 'owner' && (
                      <span className="text-xs bg-[#DC2626]/10 border border-[#DC2626]/30 text-[#DC2626] font-extrabold px-2.5 py-1 rounded-full">
                        {students.filter(s => s.feeStatus !== 'Paid').length} Overdue
                      </span>
                    )}
                  </div>

                  {/* 1-TAP WHATSAPP ALL BUTTON: CHAMPAGNE GOLD (#D4AF37) */}
                  {currentUser.role === 'owner' ? (
                    <button
                      onClick={handleSendAllFeeReminders}
                      className="w-full bg-[#D4AF37] hover:bg-[#C59B27] text-[#0B132B] font-extrabold py-3 px-4 rounded-2xl shadow-md flex items-center justify-center space-x-2 text-sm transition-all active:scale-[0.98]"
                    >
                      <Send className="w-4 h-4" />
                      <span>Send WhatsApp Reminder to All Pending</span>
                    </button>
                  ) : (
                    <div className="bg-white border border-slate-300 p-3 rounded-2xl text-xs text-slate-700 flex items-center space-x-2 shadow-sm">
                      <Lock className="w-4 h-4 text-[#0B132B] shrink-0" />
                      <span>You are in Parent View mode. Pay due fees directly via UPI in the Parent tab.</span>
                    </div>
                  )}

                  {/* Student Fee List CARDS: WHITE (#FFFFFF) */}
                  <div className="space-y-3">
                    {displayedStudents.map((st) => (
                      <div 
                        key={st.id}
                        className="bg-white border border-slate-200 rounded-2xl p-4 transition-all space-y-3 shadow-sm hover:shadow-md"
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="font-bold text-[#0F172A] text-sm flex items-center gap-1.5">
                              {st.name}
                              {st.id === activeParentStudent.id && currentUser.role === 'parent' && (
                                <span className="text-[9px] bg-slate-200 text-[#0B132B] px-1.5 py-0.2 rounded font-bold">Your Child</span>
                              )}
                            </h3>
                            <p className="text-xs text-slate-500">{st.class} • Parent: {st.parentName}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-extrabold text-sm text-[#0F172A]">₹{st.feeAmount}</p>

                            {/* PAID GREEN (#16A34A) | PENDING ORANGE (#EA580C) | OVERDUE RED (#DC2626) */}
                            {st.feeStatus === 'Paid' ? (
                              <span className="text-[10px] text-[#16A34A] font-bold bg-[#16A34A]/10 px-2 py-0.5 rounded-full inline-block mt-0.5 border border-[#16A34A]/20">
                                Paid
                              </span>
                            ) : st.daysLate > 7 ? (
                              <span className="text-[10px] text-[#DC2626] font-bold bg-[#DC2626]/10 px-2 py-0.5 rounded-full inline-block mt-0.5 border border-[#DC2626]/20">
                                {st.daysLate} Days Overdue
                              </span>
                            ) : (
                              <span className="text-[10px] text-[#EA580C] font-bold bg-[#EA580C]/10 px-2 py-0.5 rounded-full inline-block mt-0.5 border border-[#EA580C]/20">
                                {st.daysLate} Days Pending
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center justify-between pt-2.5 border-t border-slate-100">
                          <span className="text-[11px] font-mono text-slate-500">+91 {st.parentPhone}</span>
                          
                          {st.feeStatus !== 'Paid' ? (
                            currentUser.role === 'owner' ? (
                              <button
                                onClick={() => handleSingleFeeReminder(st)}
                                className="bg-[#0B132B] hover:bg-slate-800 text-[#D4AF37] px-3 py-1.5 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all shadow-sm"
                              >
                                <Send className="w-3.5 h-3.5" />
                                <span>Remind</span>
                              </button>
                            ) : (
                              <button
                                onClick={() => setActiveTab('parentView')}
                                className="bg-[#D4AF37] hover:bg-[#C59B27] text-[#0B132B] px-3 py-1.5 rounded-xl text-xs font-bold transition-all shadow-sm"
                              >
                                Pay via UPI
                              </button>
                            )
                          ) : (
                            <span className="text-xs text-[#16A34A] font-bold flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5 text-[#16A34A]" /> Settled
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ========================================= */}
              {/* TAB 2: ATTENDANCE */}
              {/* ========================================= */}
              {activeTab === 'attendance' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-base font-bold text-[#0F172A]">
                        {currentUser.role === 'parent' ? 'Child Attendance Status' : 'Daily Attendance'}
                      </h2>
                      <p className="text-xs text-slate-500">
                        {currentUser.role === 'owner' ? 'Mark P/A. Save auto-alerts absent parents!' : 'Today\'s Attendance Record'}
                      </p>
                    </div>
                    <span className="text-xs font-mono bg-[#0B132B] text-[#D4AF37] font-bold px-2.5 py-1 rounded-full">
                      {new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
                    </span>
                  </div>

                  {currentUser.role === 'parent' && (
                    <div className="bg-white border border-slate-300 p-3 rounded-2xl text-xs text-slate-700 flex items-center space-x-2 shadow-sm">
                      <Lock className="w-4 h-4 text-[#0B132B] shrink-0" />
                      <span>Viewing attendance for <strong>{activeParentStudent.name}</strong>. Only Tuition Owner can edit attendance logs.</span>
                    </div>
                  )}

                  {/* Student Attendance Cards */}
                  <div className="space-y-2.5">
                    {displayedStudents.map((st) => (
                      <div 
                        key={st.id}
                        className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between bg-white shadow-sm ${
                          st.todayAttendance === 'P' 
                            ? 'border-slate-200' 
                            : 'border-[#DC2626]/40 bg-red-50/50'
                        }`}
                      >
                        <div>
                          <h3 className="font-bold text-[#0F172A] text-sm flex items-center gap-1.5">
                            {st.name}
                            {st.id === activeParentStudent.id && currentUser.role === 'parent' && (
                              <span className="text-[9px] bg-slate-200 text-[#0B132B] px-1.5 py-0.2 rounded font-bold">Your Child</span>
                            )}
                          </h3>
                          <p className="text-xs text-slate-500">{st.batch}</p>
                        </div>

                        {currentUser.role === 'owner' ? (
                          <div className="flex items-center space-x-2">
                            <button
                              onClick={() => handleToggleAttendance(st.id)}
                              className={`w-10 h-10 rounded-xl font-black text-sm flex items-center justify-center transition-all ${
                                st.todayAttendance === 'P'
                                  ? 'bg-[#16A34A] text-white shadow-md'
                                  : 'bg-slate-100 text-slate-400 hover:text-slate-700'
                              }`}
                            >
                              P
                            </button>
                            <button
                              onClick={() => handleToggleAttendance(st.id)}
                              className={`w-10 h-10 rounded-xl font-black text-sm flex items-center justify-center transition-all ${
                                st.todayAttendance === 'A'
                                  ? 'bg-[#DC2626] text-white shadow-md'
                                  : 'bg-slate-100 text-slate-400 hover:text-slate-700'
                              }`}
                            >
                              A
                            </button>
                          </div>
                        ) : (
                          <span className={`px-3 py-1 rounded-xl font-black text-xs ${
                            st.todayAttendance === 'P' ? 'bg-[#16A34A]/10 text-[#16A34A] border border-[#16A34A]/30' : 'bg-[#DC2626]/10 text-[#DC2626] border border-[#DC2626]/30'
                          }`}>
                            {st.todayAttendance === 'P' ? 'PRESENT TODAY' : 'ABSENT TODAY'}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>

                  {/* SAVE ATTENDANCE BUTTON: CHAMPAGNE GOLD (#D4AF37) */}
                  {currentUser.role === 'owner' && (
                    <button
                      onClick={handleSaveAttendance}
                      className="w-full mt-2 bg-[#D4AF37] hover:bg-[#C59B27] text-[#0B132B] font-extrabold py-3 px-4 rounded-2xl shadow-md flex items-center justify-center space-x-2 text-sm transition-all"
                    >
                      <Check className="w-4 h-4" />
                      <span>Save Attendance & Alert Absent Parents</span>
                    </button>
                  )}
                </div>
              )}

              {/* ========================================= */}
              {/* TAB 3: TESTS & BAR CHARTS */}
              {/* ========================================= */}
              {activeTab === 'tests' && (
                <div className="space-y-4">
                  <div>
                    <h2 className="text-base font-bold text-[#0F172A]">
                      {currentUser.role === 'parent' ? `${activeParentStudent.name}'s Test Report` : 'Weekly Test Performance'}
                    </h2>
                    <p className="text-xs text-slate-500">Scores, batch rank & 6-test history chart</p>
                  </div>

                  <div className="space-y-4">
                    {displayedStudents.map((st) => (
                      <div key={st.id} className="bg-white border border-slate-200 rounded-2xl p-4 space-y-3 shadow-sm">
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="font-bold text-[#0F172A] text-sm flex items-center gap-1.5">
                              {st.name}
                              {st.id === activeParentStudent.id && currentUser.role === 'parent' && (
                                <span className="text-[9px] bg-slate-200 text-[#0B132B] px-1.5 py-0.2 rounded font-bold">Your Child</span>
                              )}
                            </h3>
                            <p className="text-xs text-slate-500">{st.class}</p>
                          </div>
                          <div className="text-right">
                            <span className="text-xs font-extrabold bg-[#0B132B] text-[#D4AF37] px-2.5 py-1 rounded-full">
                              Batch Rank #{st.rank}
                            </span>
                            <p className="text-xs font-bold text-[#16A34A] mt-1">{st.weeklyTestMarks}</p>
                          </div>
                        </div>

                        {/* LAST 6 TESTS BAR CHART */}
                        <div className="bg-[#F4F6F9] p-3 rounded-xl border border-slate-200 space-y-1.5">
                          <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Last 6 Tests Progress</p>
                          <div className="flex items-end justify-between h-20 pt-2 gap-1.5">
                            {st.testHistory.map((t, idx) => {
                              const heightPct = Math.round((t.mark / 50) * 100);
                              return (
                                <div key={idx} className="flex-1 flex flex-col items-center gap-1">
                                  <span className="text-[9px] text-slate-600 font-bold">{t.mark}</span>
                                  <div className="w-full bg-slate-200 rounded-t-md h-full flex items-end overflow-hidden">
                                    <div 
                                      className="w-full bg-[#0B132B] rounded-t-md transition-all duration-500"
                                      style={{ height: `${heightPct}%` }}
                                    />
                                  </div>
                                  <span className="text-[9px] text-slate-500 font-medium">{t.test}</span>
                                </div>
                              );
                            })}
                          </div>
                        </div>

                        {currentUser.role === 'owner' && (
                          <button
                            onClick={() => handleShareTestReport(st)}
                            className="w-full bg-[#0B132B] hover:bg-slate-800 text-[#D4AF37] py-2 rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 transition-all shadow-sm"
                          >
                            <Share2 className="w-3.5 h-3.5" />
                            <span>Share Report Card on WhatsApp</span>
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ========================================= */}
              {/* TAB 4: PARENT VIEW */}
              {/* ========================================= */}
              {activeTab === 'parentView' && (
                <div className="space-y-4">
                  {/* Active Child Overview Card */}
                  <div className="bg-[#0B132B] text-white p-4 rounded-2xl flex items-center justify-between shadow-md border-b-2 border-[#D4AF37]">
                    <div>
                      <span className="text-[10px] uppercase tracking-wider font-bold text-[#D4AF37]">Parent Dashboard</span>
                      <p className="text-sm font-bold text-white">{activeParentStudent.name} ({activeParentStudent.class})</p>
                      <p className="text-[10px] text-slate-300">Parent: {activeParentStudent.parentName} (+91 {activeParentStudent.parentPhone})</p>
                    </div>

                    {currentUser.role === 'owner' && (
                      <div className="text-right">
                        <span className="text-[9px] text-[#D4AF37] font-bold block">Owner Preview</span>
                        <select
                          value={activeParentStudent.id}
                          onChange={(e) => {
                            const found = students.find(s => s.id === e.target.value);
                            if (found) setCurrentUser({ role: 'owner', previewStudentId: found.id });
                          }}
                          className="bg-slate-900 border border-slate-700 text-xs rounded-xl px-2 py-1 text-slate-200 outline-none mt-1"
                        >
                          {students.map(st => (
                            <option key={st.id} value={st.id}>{st.name}</option>
                          ))}
                        </select>
                      </div>
                    )}
                  </div>

                  {/* Parent Mobile App View UI - WHITE CARDS */}
                  <div className="bg-white border border-slate-200 rounded-3xl p-4 space-y-4 shadow-md relative">
                    
                    {/* Attendance Score */}
                    <div className="bg-[#F4F6F9] p-4 rounded-2xl border border-slate-200 flex items-center justify-between">
                      <div>
                        <p className="text-xs text-slate-500 font-medium">Overall Attendance</p>
                        <h3 className="text-2xl font-black text-[#0B132B] mt-0.5">{activeParentStudent.attendancePercent}%</h3>
                        <p className="text-[10px] text-slate-500 mt-1">Status Today: 
                          <strong className={activeParentStudent.todayAttendance === 'P' ? 'text-[#16A34A] ml-1' : 'text-[#DC2626] ml-1'}>
                            {activeParentStudent.todayAttendance === 'P' ? 'PRESENT' : 'ABSENT'}
                          </strong>
                        </p>
                      </div>
                      <div className="w-12 h-12 rounded-full border-4 border-[#0B132B] flex items-center justify-center font-bold text-xs text-[#0B132B] bg-white">
                        {activeParentStudent.attendancePercent}%
                      </div>
                    </div>

                    {/* Today Homework */}
                    <div className="bg-[#F4F6F9] p-4 rounded-2xl border border-slate-200 space-y-1">
                      <div className="flex items-center space-x-1.5 text-[#0B132B] text-xs font-bold">
                        <BookOpen className="w-4 h-4 text-[#D4AF37]" />
                        <span>Today's Homework</span>
                      </div>
                      <p className="text-xs text-slate-700 leading-relaxed pt-1 font-medium">
                        "{activeParentStudent.homework}"
                      </p>
                    </div>

                    {/* Fee Due & Pay by UPI */}
                    <div className="bg-[#F4F6F9] p-4 rounded-2xl border border-slate-200 space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-xs text-slate-500 font-medium">Monthly Fee Due</span>
                        <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                          activeParentStudent.feeStatus === 'Paid' 
                            ? 'bg-[#16A34A]/10 text-[#16A34A] border border-[#16A34A]/30' 
                            : activeParentStudent.daysLate > 7
                            ? 'bg-[#DC2626]/10 text-[#DC2626] border border-[#DC2626]/30'
                            : 'bg-[#EA580C]/10 text-[#EA580C] border border-[#EA580C]/30'
                        }`}>
                          {activeParentStudent.feeStatus}
                        </span>
                      </div>

                      <div className="flex items-baseline justify-between">
                        <div>
                          <span className="text-2xl font-black text-[#0F172A]">₹{activeParentStudent.feeAmount}</span>
                          <p className="text-[10px] text-slate-500">Due Date: 5th of every month</p>
                        </div>

                        {activeParentStudent.feeStatus !== 'Paid' ? (
                          <button
                            onClick={() => setUpiModal(true)}
                            className="bg-[#D4AF37] hover:bg-[#C59B27] text-[#0B132B] px-4 py-2.5 rounded-xl text-xs font-extrabold shadow-md flex items-center space-x-1.5 transition-all"
                          >
                            <QrCode className="w-4 h-4" />
                            <span>Pay by UPI</span>
                          </button>
                        ) : (
                          <span className="text-xs text-[#16A34A] font-bold flex items-center gap-1">
                            <ShieldCheck className="w-4 h-4" /> Receipt Generated
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Refer a Friend Form for Parents */}
                    <div className="bg-[#F4F6F9] p-4 rounded-2xl border border-slate-200 space-y-3">
                      <div className="flex items-center space-x-1.5 text-[#0B132B] text-xs font-bold">
                        <Gift className="w-4 h-4 text-[#D4AF37]" />
                        <span>Refer a Friend / Relative</span>
                      </div>
                      <form onSubmit={(e) => handleAddReferral(e, activeParentStudent.name)} className="space-y-2">
                        <input
                          type="text"
                          value={referralName}
                          onChange={(e) => setReferralName(e.target.value)}
                          placeholder="Friend's / Student Name"
                          className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-[#0F172A] outline-none"
                        />
                        <div className="flex gap-2">
                          <select
                            value={referralClass}
                            onChange={(e) => setReferralClass(e.target.value)}
                            className="bg-white border border-slate-300 rounded-xl px-2 py-2 text-xs text-slate-700 outline-none"
                          >
                            <option value="Class 8">Class 8</option>
                            <option value="Class 9">Class 9</option>
                            <option value="Class 10">Class 10</option>
                          </select>
                          <button
                            type="submit"
                            className="flex-1 bg-[#0B132B] hover:bg-slate-800 text-[#D4AF37] font-bold py-2 rounded-xl text-xs shadow-md transition-all"
                          >
                            Submit Referral
                          </button>
                        </div>
                      </form>
                    </div>

                  </div>
                </div>
              )}

              {/* ========================================= */}
              {/* TAB 5: OWNER DASHBOARD */}
              {/* ========================================= */}
              {activeTab === 'dashboard' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-base font-bold text-[#0F172A]">Owner Overview</h2>
                      <p className="text-xs text-slate-500">Tuition revenue & referral leads</p>
                    </div>
                    {currentUser.role !== 'owner' && (
                      <span className="text-[10px] bg-amber-100 text-amber-800 border border-amber-300 px-2 py-0.5 rounded-full font-bold">
                        View Only
                      </span>
                    )}
                  </div>

                  {/* Financial Metrics Cards - PAID (GREEN) VS PENDING/OVERDUE */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-white border border-slate-200 p-3.5 rounded-2xl space-y-1 shadow-sm">
                      <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Fees Collected</p>
                      <p className="text-xl font-black text-[#16A34A]">₹{totalCollected.toLocaleString('en-IN')}</p>
                      <p className="text-[10px] text-[#16A34A] font-bold">In hand this month</p>
                    </div>
                    <div className="bg-white border border-slate-200 p-3.5 rounded-2xl space-y-1 shadow-sm">
                      <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Fees Pending</p>
                      <p className="text-xl font-black text-[#DC2626]">₹{totalPending.toLocaleString('en-IN')}</p>
                      <p className="text-[10px] text-[#DC2626] font-bold">Overdue total</p>
                    </div>
                  </div>

                  {/* Total Active Students */}
                  <div className="bg-white border border-slate-200 p-4 rounded-2xl flex items-center justify-between shadow-sm">
                    <div>
                      <p className="text-xs text-slate-500 font-medium">Total Enrolled Students</p>
                      <h3 className="text-2xl font-black text-[#0B132B] mt-0.5">{students.length} Students</h3>
                      <p className="text-[10px] text-slate-400">Across 2 active tuition batches</p>
                    </div>
                    <div className="p-3 bg-[#0B132B] text-[#D4AF37] rounded-2xl">
                      <Users className="w-6 h-6" />
                    </div>
                  </div>

                  {/* Referral Enquiries */}
                  <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-3 shadow-sm">
                    <div className="flex items-center justify-between">
                      <h3 className="font-bold text-sm text-[#0F172A] flex items-center gap-1.5">
                        <Share2 className="w-4 h-4 text-[#D4AF37]" />
                        <span>Refer a Friend Enquiries</span>
                      </h3>
                      <span className="text-[10px] font-bold bg-[#0B132B] text-[#D4AF37] px-2 py-0.5 rounded-full">
                        {referrals.length} Leads
                      </span>
                    </div>

                    <div className="space-y-2">
                      {referrals.map((ref) => (
                        <div key={ref.id} className="bg-[#F4F6F9] p-3 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
                          <div>
                            <p className="font-bold text-[#0F172A]">{ref.name} ({ref.class})</p>
                            <p className="text-[10px] text-slate-500 mt-0.5">Referred by: <span className="text-[#0B132B] font-bold">{ref.referrer}</span></p>
                          </div>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                            ref.status === 'Joined' ? 'bg-[#16A34A]/10 text-[#16A34A] border-[#16A34A]/30' : 'bg-[#EA580C]/10 text-[#EA580C] border-[#EA580C]/30'
                          }`}>
                            {ref.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>
              )}

            </main>

            {/* --- MODAL 1: WHATSAPP SIMULATOR --- */}
            {whatsappModal.open && (
              <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
                <div className="bg-white border border-slate-300 rounded-3xl max-w-xs w-full p-5 space-y-4 shadow-2xl">
                  <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                    <div className="flex items-center space-x-2 text-[#16A34A]">
                      <MessageSquare className="w-4 h-4" />
                      <h3 className="font-bold text-sm text-[#0F172A]">WhatsApp Alert Dispatch</h3>
                    </div>
                    <button onClick={() => setWhatsappModal({ ...whatsappModal, open: false })} className="text-xs text-slate-400">✕</button>
                  </div>

                  <div className="space-y-2 text-xs">
                    <p className="text-slate-500">Recipient: <span className="text-[#0F172A] font-bold">{whatsappModal.recipient}</span></p>
                    <div className="bg-slate-100 border border-slate-200 p-3 rounded-2xl text-slate-800 leading-relaxed whitespace-pre-line text-[11px] font-sans">
                      {whatsappModal.message}
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      setWhatsappModal({ ...whatsappModal, open: false });
                      triggerToast('Demo only: no WhatsApp message was sent. Use the prepared text manually.');
                    }}
                    className="w-full bg-[#16A34A] hover:bg-emerald-700 text-white font-extrabold py-2.5 rounded-xl text-xs flex items-center justify-center space-x-2 shadow-md"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Confirm & Send Alert</span>
                  </button>
                </div>
              </div>
            )}

            {/* --- MODAL 2: PAY BY UPI SIMULATOR --- */}
            {upiModal && (
              <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
                <div className="bg-white border border-slate-300 rounded-3xl max-w-xs w-full p-5 space-y-4 shadow-2xl text-center">
                  <div className="space-y-1">
                    <h3 className="font-bold text-base text-[#0F172A]">Pay Tuition Fee</h3>
                    <p className="text-xs text-slate-500">Scan QR or click below to complete UPI payment</p>
                  </div>

                  {/* QR Box */}
                  <div className="bg-[#F4F6F9] p-4 rounded-2xl w-40 h-40 mx-auto flex flex-col items-center justify-center space-y-2 shadow-inner border border-slate-300">
                    <QrCode className="w-28 h-28 text-[#0B132B]" />
                    <span className="text-[10px] font-bold text-slate-800 font-mono">UPI ID: tuition@upi</span>
                  </div>

                  <div className="space-y-2">
                    <button
                      onClick={() => markFeePaid(activeParentStudent.id)}
                      className="w-full bg-[#16A34A] hover:bg-emerald-700 text-white font-extrabold py-2.5 rounded-xl text-xs shadow-md"
                    >
                      Demo only — mark fee as paid
                    </button>
                    <button
                      onClick={() => setUpiModal(false)}
                      className="w-full bg-slate-200 text-slate-700 py-2 rounded-xl text-xs font-semibold"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* --- BOTTOM NAVIGATION BAR: NAVY BLUE (#0B132B) --- */}
            <nav className="bg-[#0B132B] text-slate-300 border-t border-slate-800 fixed bottom-0 max-w-md w-full z-40 grid grid-cols-5 py-2 px-1 text-center shadow-lg">
              
              <button
                onClick={() => setActiveTab('fees')}
                className={`flex flex-col items-center space-y-1 transition-all ${
                  activeTab === 'fees' ? 'text-[#D4AF37] font-bold scale-105' : 'text-slate-400 hover:text-white'
                }`}
              >
                <IndianRupee className="w-4 h-4" />
                <span className="text-[10px]">Fees</span>
              </button>

              <button
                onClick={() => setActiveTab('attendance')}
                className={`flex flex-col items-center space-y-1 transition-all ${
                  activeTab === 'attendance' ? 'text-[#D4AF37] font-bold scale-105' : 'text-slate-400 hover:text-white'
                }`}
              >
                <UserCheck className="w-4 h-4" />
                <span className="text-[10px]">Att.</span>
              </button>

              <button
                onClick={() => setActiveTab('tests')}
                className={`flex flex-col items-center space-y-1 transition-all ${
                  activeTab === 'tests' ? 'text-[#D4AF37] font-bold scale-105' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Award className="w-4 h-4" />
                <span className="text-[10px]">Tests</span>
              </button>

              <button
                onClick={() => setActiveTab('parentView')}
                className={`flex flex-col items-center space-y-1 transition-all ${
                  activeTab === 'parentView' ? 'text-[#D4AF37] font-bold scale-105' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Smartphone className="w-4 h-4" />
                <span className="text-[10px]">Parent</span>
              </button>

              <button
                onClick={() => setActiveTab('dashboard')}
                className={`flex flex-col items-center space-y-1 transition-all ${
                  activeTab === 'dashboard' ? 'text-[#D4AF37] font-bold scale-105' : 'text-slate-400 hover:text-white'
                }`}
              >
                <BarChart3 className="w-4 h-4" />
                <span className="text-[10px]">Owner</span>
              </button>

            </nav>

          </>
        )}

      </div>
    </div>
  );
}